# bunnystorekub starter
1. Upload `index.html` to the root of your GitHub repository.
2. In Supabase > SQL Editor, run `supabase.sql`.
3. In Supabase > Project Settings > API, copy the Project URL and anon/public key into the two constants near the bottom of index.html.
4. Create the admin account in Supabase Authentication > Users.
5. Add the admin user to `public.admin_users` using SQL:
   insert into public.admin_users(user_id)
   select id from auth.users where email = 'YOUR_ADMIN_EMAIL'
   on conflict (user_id) do nothing;
6. Deploy the repository using Cloudflare Pages (connect GitHub; framework preset None; build command blank; output directory `/`).

Security notes:
- Never put a Supabase service_role key in browser code or GitHub.
- Use only the anon/public key in `index.html`.
- Admin access is controlled by `admin_users` and row-level security.
- Customer reviews are submitted unapproved and only show publicly after an admin approves them. An admin review moderation screen is not yet included in this starter.
